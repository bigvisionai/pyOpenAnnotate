# Annotation-Tool

Simple and intuitive automated annotation tool using OpenCV.

## Annotate Images

```
annotate <images_directory_path>
```

## Annotate Video
```
annotate <path_to_video_file>
```


