# Annotation-Tool

Simple and intuitive automated annotation tool using OpenCV.
